package com.shugarich.taxist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 28, 26, 28)
            setBackgroundColor(Color.rgb(18, 19, 22))
        }
        val title = TextView(this).apply {
            text = "TAXI ASSISTANT"
            textSize = 28f
            setTextColor(Color.rgb(255, 193, 7))
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "\nАвтоматический анализ карточки заказа\n\nПоказывает примерную оплату пассажира, оценочный доход водителя, ₽/ч, расстояние и время маршрута.\n\nНе принимает и не отклоняет заказы автоматически."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 22)
        }
        val accessibility = Button(this).apply {
            text = "1. Включить чтение Яндекс Про"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val overlay = Button(this).apply {
            text = "2. Разрешить показ поверх приложений"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(title)
        root.addView(info)
        root.addView(accessibility)
        root.addView(overlay)
        setContentView(root)
    }
}
