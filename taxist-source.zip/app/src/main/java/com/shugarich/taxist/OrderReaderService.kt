package com.shugarich.taxist

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class OrderReaderService : AccessibilityService() {
    private var windowManager: WindowManager? = null
    private var overlay: LinearLayout? = null
    private var lastSummary: String = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName != "ru.yandex.taximeter") {
            // Keep the overlay only while Yandex Pro is the active app.
            if (packageName != this.packageName) hideOverlay()
            return
        }

        val strings = mutableListOf<String>()
        fun collect(node: android.view.accessibility.AccessibilityNodeInfo?) {
            if (node == null) return
            node.text?.toString()?.takeIf { it.isNotBlank() }?.let(strings::add)
            node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(strings::add)
            for (i in 0 until node.childCount) collect(node.getChild(i))
        }
        collect(rootInActiveWindow)
        val fullText = strings.distinct().joinToString(" · ")
        // The offer card is considered active only while the accept button is visible.
        if (fullText.isBlank() || !fullText.contains("Принять", ignoreCase = true)) {
            hideOverlay()
            return
        }

        val passengerFare = Regex("(?:≈|~)?\\s*([0-9]{2,5})\\s*(?:₽|руб)", RegexOption.IGNORE_CASE)
            .find(fullText)?.groupValues?.get(1)?.toIntOrNull()
        val distanceKm = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*км", RegexOption.IGNORE_CASE)
            .find(fullText)?.groupValues?.get(1)?.replace(',', '.')?.toDoubleOrNull()
        val durationMinutes = Regex("([0-9]{1,3})\\s*мин", RegexOption.IGNORE_CASE)
            .find(fullText)?.groupValues?.get(1)?.toIntOrNull()

        // Preliminary estimate based on ~63% retained from the user's sample trips.
        val driverNet = passengerFare?.let { (it * 0.63).toInt() }
        val hourly = if (driverNet != null && durationMinutes != null && durationMinutes > 0) {
            (driverNet * 60.0 / durationMinutes).toInt()
        } else null
        val kmText = distanceKm?.let { String.format(Locale.US, "%.1f км", it) } ?: "— км"
        val summary = buildString {
            append("≈ ").append(passengerFare?.let { "$it ₽ пассажир" } ?: "считываю цену…")
            append("\nДоход водителя: ").append(driverNet?.let { "≈ $it ₽" } ?: "пока не определён")
            append("\n").append(hourly?.let { "≈ $it ₽/ч" } ?: "₽/ч: ожидаю время маршрута")
            append("\nМаршрут: ").append(kmText)
            append(durationMinutes?.let { " · $it мин" } ?: "")
        }
        if (summary != lastSummary) {
            lastSummary = summary
            showOverlay(summary)
        }
    }

    private fun showOverlay(text: String) {
        try {
            if (overlay == null) {
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 12, 16, 12)
                    setBackgroundColor(Color.argb(150, 18, 20, 25))
                }
                val label = TextView(this).apply {
                    tag = "label"
                    setTextColor(Color.WHITE)
                    textSize = 14f
                }
                val close = TextView(this).apply {
                    text = "✕ Скрыть"
                    textSize = 12f
                    setTextColor(Color.rgb(255, 193, 7))
                    gravity = Gravity.END
                    setPadding(0, 8, 0, 0)
                    setOnClickListener { hideOverlay() }
                }
                box.addView(label)
                box.addView(close)
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.END
                    x = 10
                    y = 150
                    alpha = 0.88f
                }
                windowManager?.addView(box, params)
                overlay = box
            }
            overlay?.findViewWithTag<TextView>("label")?.text = text
        } catch (_: Exception) {
            hideOverlay()
        }
    }

    private fun hideOverlay() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        overlay = null
        lastSummary = ""
    }

    override fun onInterrupt() { hideOverlay() }
    override fun onDestroy() { hideOverlay(); super.onDestroy() }
}
