# Taxi Assistant (prototype)

Android prototype for reading visible Yandex Pro offer-card text through Android Accessibility Service and displaying a translucent overlay. It does not accept or reject offers automatically.

The fare and driver income are estimates. Driver net currently uses a provisional 63% retention ratio based on examples supplied during development. Parsing depends on text exposed by the installed Yandex Pro version and may need adjustment after testing.

## Build

GitHub Actions builds a debug APK from the project files. Download `taxi-assistant-debug` from the successful workflow run under Actions > Artifacts.

## Permissions

After installing, open the app and enable its Accessibility Service in Android Accessibility settings. Allow display over other apps if requested. Only enable the service if you understand that it can read visible interface text.
