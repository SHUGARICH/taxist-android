plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.shugarich.taxist"
    compileSdk = 35

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.shugarich.taxist"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")
    // Реальная реализация org.json для JVM-тестов (в android.jar только заглушки).
    testImplementation("org.json:json:20240303")
}
