package com.shugarich.taxist

import com.shugarich.taxist.model.RouteFailure
import com.shugarich.taxist.model.RouteResult
import com.shugarich.taxist.route.GeoPoint
import com.shugarich.taxist.route.Geocoder
import com.shugarich.taxist.route.NominatimParser
import com.shugarich.taxist.route.OsrmParser
import com.shugarich.taxist.route.RouteException
import com.shugarich.taxist.route.RoutePipeline
import com.shugarich.taxist.route.RouteProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class RouteComponentsTest {

    private fun failure(block: () -> Unit): RouteFailure {
        try {
            block()
        } catch (e: RouteException) {
            return e.failure
        }
        fail("RouteException expected")
        throw IllegalStateException()
    }

    @Test
    fun osrmSuccess() {
        val r = OsrmParser.parse("""{"code":"Ok","routes":[{"distance":16012.4,"duration":1738.6}]}""")
        assertEquals(16012, r.distanceMeters)
        assertEquals(1739, r.durationSeconds)
        assertEquals(false, r.trafficAware)
    }

    @Test
    fun osrmNoRouteAndBadResponses() {
        assertEquals(RouteFailure.NO_ROUTE, failure { OsrmParser.parse("""{"code":"NoRoute"}""") })
        assertEquals(RouteFailure.NO_ROUTE, failure { OsrmParser.parse("""{"code":"Ok","routes":[]}""") })
        assertEquals(RouteFailure.SERVER_ERROR, failure { OsrmParser.parse("not json") })
        assertEquals(RouteFailure.SERVER_ERROR, failure { OsrmParser.parse("""{"code":"InvalidQuery"}""") })
        assertEquals(RouteFailure.SERVER_ERROR,
            failure { OsrmParser.parse("""{"code":"Ok","routes":[{"distance":10,"duration":0}]}""") })
    }

    @Test
    fun nominatimResults() {
        val p = NominatimParser.parse("""[{"lat":"55.7600","lon":"37.6100"}]""")
        assertEquals(55.76, p.lat, 1e-9)
        assertEquals(RouteFailure.ADDRESS_NOT_FOUND, failure { NominatimParser.parse("[]") })
        assertEquals(RouteFailure.SERVER_ERROR, failure { NominatimParser.parse("oops") })
    }

    @Test
    fun nominatimAmbiguousWhenCandidatesFarApart() {
        val json = """[{"lat":"55.76","lon":"37.61"},{"lat":"59.93","lon":"30.33"}]"""
        assertEquals(RouteFailure.ADDRESS_AMBIGUOUS, failure { NominatimParser.parse(json) })
    }

    @Test
    fun nominatimNearbyCandidatesAreFine() {
        val json = """[{"lat":"55.7600","lon":"37.6100"},{"lat":"55.7610","lon":"37.6110"}]"""
        assertEquals(55.76, NominatimParser.parse(json).lat, 1e-9)
    }

    @Test
    fun pipelineRoutesBetweenPickupAndDestinationOnly() {
        val points = mapOf(
            "ул. ленина, 5, москва" to GeoPoint(1.0, 2.0),
            "невский проспект, 10, москва" to GeoPoint(3.0, 4.0),
        )
        val queries = ArrayList<String>()
        val geocoder = object : Geocoder {
            override fun geocode(query: String): GeoPoint {
                queries.add(query)
                return points[query.lowercase()] ?: throw RouteException(RouteFailure.ADDRESS_NOT_FOUND)
            }
        }
        val provider = object : RouteProvider {
            var lastFrom: GeoPoint? = null
            var lastTo: GeoPoint? = null
            override fun route(from: GeoPoint, to: GeoPoint): RouteResult {
                lastFrom = from
                lastTo = to
                return RouteResult(16000, 1740, false)
            }
        }
        val result = RoutePipeline(geocoder, provider) { "Москва" }
            .compute("ул. Ленина, 5", "Невский проспект, 10")
        assertEquals(16000, result.distanceMeters)
        assertEquals(GeoPoint(1.0, 2.0), provider.lastFrom)
        assertEquals(GeoPoint(3.0, 4.0), provider.lastTo)
        assertEquals(2, queries.size)
    }

    @Test
    fun cityIsNotDuplicated() {
        val queries = ArrayList<String>()
        val geocoder = object : Geocoder {
            override fun geocode(query: String): GeoPoint {
                queries.add(query)
                return GeoPoint(0.0, 0.0)
            }
        }
        val provider = object : RouteProvider {
            override fun route(from: GeoPoint, to: GeoPoint) = RouteResult(1, 1, false)
        }
        RoutePipeline(geocoder, provider) { "Москва" }.compute("Москва, Тверская, 1", "Арбат, 10")
        assertEquals("Москва, Тверская, 1", queries[0])
        assertEquals("Арбат, 10, Москва", queries[1])
    }
}
