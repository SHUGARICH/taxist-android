package com.shugarich.taxist

import com.shugarich.taxist.income.IncomeCalculator
import com.shugarich.taxist.income.IncomeConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class IncomeCalculatorTest {

    @Test
    fun hourlyIncomeFromTripTime() {
        // 520 ₽ за 29 минут ≈ 1 076 ₽/ч
        assertEquals(1076, IncomeCalculator.hourly(520, 29 * 60))
    }

    @Test
    fun hourlyIsNullWithoutTripTime() {
        assertNull(IncomeCalculator.hourly(520, null))
        assertNull(IncomeCalculator.hourly(520, 0))
        assertNull(IncomeCalculator.hourly(520, -5))
    }

    @Test
    fun hourlyIsNullWithoutIncome() {
        assertNull(IncomeCalculator.hourly(null, 1740))
    }

    @Test
    fun driverNetUsesConfigurablePercent() {
        assertEquals(328, IncomeCalculator.driverNet(520, IncomeConfig(63.0)))
        assertEquals(416, IncomeCalculator.driverNet(520, IncomeConfig(80.0)))
    }

    @Test
    fun driverNetIsNullWithoutFareOrWithBadPercent() {
        assertNull(IncomeCalculator.driverNet(null, IncomeConfig(63.0)))
        assertNull(IncomeCalculator.driverNet(520, IncomeConfig(0.0)))
        assertNull(IncomeCalculator.driverNet(520, IncomeConfig(150.0)))
    }
}
