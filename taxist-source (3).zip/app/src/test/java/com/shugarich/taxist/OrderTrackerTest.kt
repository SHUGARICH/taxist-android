package com.shugarich.taxist

import com.shugarich.taxist.model.OrderCard
import com.shugarich.taxist.model.RouteFailure
import com.shugarich.taxist.model.RouteResult
import com.shugarich.taxist.model.RouteState
import com.shugarich.taxist.model.TrackerSnapshot
import com.shugarich.taxist.route.OrderTracker
import com.shugarich.taxist.route.RouteException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.ArrayDeque
import java.util.concurrent.Executor

class OrderTrackerTest {

    private class ManualExecutor : Executor {
        val queue = ArrayDeque<Runnable>()
        override fun execute(command: Runnable) { queue.add(command) }
        fun runNext() { queue.poll()?.run() }
    }

    private val snaps = ArrayList<TrackerSnapshot>()
    private val exec = ManualExecutor()
    private var calls = 0
    private var enabled = true
    private var failWith: RouteException? = null

    private fun tracker() = OrderTracker(
        executor = exec,
        compute = { a, _ ->
            calls++
            failWith?.let { throw it }
            if (a == "A1") RouteResult(1000, 100, false) else RouteResult(2000, 200, false)
        },
        routingEnabled = { enabled },
        listener = { snaps.add(it) },
    )

    private val order1 = OrderCard("A1", "B1", 500, 2)
    private val order2 = OrderCard("A2", "B2", 700, 2)

    @Test
    fun routeIsComputedForPickupToDestination() {
        val t = tracker()
        t.onCard(order1)
        assertEquals(RouteState.Loading, snaps.last().route)
        exec.runNext()
        val ready = snaps.last().route as RouteState.Ready
        assertEquals(1000, ready.result.distanceMeters)
        assertEquals(order1, snaps.last().card)
    }

    @Test
    fun staleResultFromPreviousOrderIsIgnored() {
        val t = tracker()
        t.onCard(order1)        // job1 в очереди
        t.onCard(order2)        // job2 в очереди, поколение сменилось
        exec.runNext()          // ответ для order1 приходит после смены заказа
        assertTrue(snaps.none { it.route is RouteState.Ready })
        assertEquals(RouteState.Loading, snaps.last().route)
        assertEquals(order2, snaps.last().card)
        exec.runNext()          // ответ для order2
        val ready = snaps.last().route as RouteState.Ready
        assertEquals(2000, ready.result.distanceMeters)
        assertEquals(order2, snaps.last().card)
    }

    @Test
    fun lateResultAfterCardDisappearedIsIgnored() {
        val t = tracker()
        t.onCard(order1)
        t.clear()
        val countAfterClear = snaps.size
        exec.runNext()
        assertEquals(countAfterClear, snaps.size)
        assertNull(snaps.last().card)
        assertEquals(RouteState.Idle, snaps.last().route)
    }

    @Test
    fun oldSnapshotIsNotLatestAfterChange() {
        val t = tracker()
        t.onCard(order1)
        val old = snaps.last()
        t.onCard(order2)
        assertFalse(t.isLatest(old))
        assertTrue(t.isLatest(snaps.last()))
    }

    @Test
    fun routerErrorIsReported() {
        failWith = RouteException(RouteFailure.NO_NETWORK)
        val t = tracker()
        t.onCard(order1)
        exec.runNext()
        val failed = snaps.last().route as RouteState.Failed
        assertEquals(RouteFailure.NO_NETWORK, failed.reason)
    }

    @Test
    fun unexpectedExceptionBecomesServerError() {
        val t = OrderTracker(exec, { _, _ -> throw IllegalStateException("boom") }, { true }, { snaps.add(it) })
        t.onCard(order1)
        exec.runNext()
        assertEquals(RouteFailure.SERVER_ERROR, (snaps.last().route as RouteState.Failed).reason)
    }

    @Test
    fun missingDestinationDoesNotCallRouter() {
        val t = tracker()
        t.onCard(OrderCard("A1", null, 500, 1))
        assertEquals(RouteState.NoDestination, snaps.last().route)
        assertTrue(exec.queue.isEmpty())
        assertEquals(0, calls)
    }

    @Test
    fun routingDisabledDoesNotCallRouter() {
        enabled = false
        val t = tracker()
        t.onCard(order1)
        assertEquals(RouteState.Disabled, snaps.last().route)
        assertTrue(exec.queue.isEmpty())
    }

    @Test
    fun enablingRoutingStartsCalculationForSameCard() {
        enabled = false
        val t = tracker()
        t.onCard(order1)
        enabled = true
        t.onCard(order1)
        assertEquals(RouteState.Loading, snaps.last().route)
        exec.runNext()
        assertTrue(snaps.last().route is RouteState.Ready)
    }

    @Test
    fun sameCardRepeatedEventsDoNotRestartOrNotify() {
        val t = tracker()
        t.onCard(order1)
        t.onCard(order1)
        t.onCard(order1)
        assertEquals(1, snaps.size)
        assertEquals(1, exec.queue.size)
    }

    @Test
    fun fareChangeKeepsRouteForSameAddresses() {
        val t = tracker()
        t.onCard(order1)
        exec.runNext()
        t.onCard(order1.copy(fareRub = 650))
        assertEquals(650, snaps.last().card?.fareRub)
        assertTrue(snaps.last().route is RouteState.Ready)
        assertEquals(1, calls)
    }

    @Test
    fun cacheAvoidsRepeatedRequests() {
        val t = tracker()
        t.onCard(order1)
        exec.runNext()
        t.clear()
        t.onCard(order1)
        assertTrue(snaps.last().route is RouteState.Ready)
        assertEquals(1, calls)
    }

    @Test
    fun newOrderNeverShowsPreviousOrderRoute() {
        val t = tracker()
        t.onCard(order1)
        exec.runNext()
        t.onCard(order2)
        assertEquals(RouteState.Loading, snaps.last().route)
        assertEquals(order2, snaps.last().card)
    }

    @Test
    fun clearIsIdempotent() {
        val t = tracker()
        t.clear()
        assertTrue(snaps.isEmpty())
    }
}
