package com.shugarich.taxist

import com.shugarich.taxist.model.RawNode
import com.shugarich.taxist.parser.OrderCardParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderCardParserTest {

    private fun n(text: String, top: Int, height: Int = 40, left: Int = 20) =
        RawNode(text, null, top, left, height)

    private val accept = n("Принять", 1500, 80)

    @Test
    fun extractsPickupDestinationAndFareSeparately() {
        val r = OrderCardParser.parse(listOf(
            n("Комфорт", 100),
            n("520 ₽", 150, 90),
            n("ул. Ленина, 5", 300),
            n("3 мин · 1,2 км", 340),
            n("Невский проспект, 10", 420),
            accept,
        ))
        assertTrue(r.isOffer)
        assertEquals("ул. Ленина, 5", r.card.pickupAddress)
        assertEquals("Невский проспект, 10", r.card.destinationAddress)
        assertEquals(520, r.card.fareRub)
    }

    @Test
    fun pickupDistanceAndTimeNeverLeakIntoCard() {
        val r = OrderCardParser.parse(listOf(
            n("520 ₽", 150, 90),
            n("1,2 км", 200),
            n("3 мин", 220),
            n("3 мин · 1,2 км", 240),
            n("ул. Ленина, 5 · 1,2 км · 3 мин", 300),
            n("Невский проспект, 10", 420),
            accept,
        ))
        val all = "${r.card.pickupAddress} ${r.card.destinationAddress}"
        assertFalse(all.contains("км"))
        assertFalse(all.contains("мин"))
        assertEquals("ул. Ленина, 5", r.card.pickupAddress)
        assertEquals(2, r.card.addressCount)
    }

    @Test
    fun missingDestination() {
        val r = OrderCardParser.parse(listOf(n("ул. Ленина, 5", 300), n("450 ₽", 150, 90), accept))
        assertEquals("ул. Ленина, 5", r.card.pickupAddress)
        assertNull(r.card.destinationAddress)
        assertEquals(1, r.card.addressCount)
    }

    @Test
    fun addressesWithDigitsAndAbbreviations() {
        val r = OrderCardParser.parse(listOf(
            n("пр-т Мира, д. 12к3", 300),
            n("ул. 8 Марта, 4/1", 420),
            accept,
        ))
        assertEquals("пр-т Мира, д. 12к3", r.card.pickupAddress)
        assertEquals("ул. 8 Марта, 4/1", r.card.destinationAddress)
    }

    @Test
    fun threeAddressesMeansDestinationUndefined() {
        val r = OrderCardParser.parse(listOf(
            n("ул. Ленина, 5", 300), n("ул. Гагарина, 7", 360), n("Невский проспект, 10", 420), accept,
        ))
        assertEquals("ул. Ленина, 5", r.card.pickupAddress)
        assertNull(r.card.destinationAddress)
        assertEquals(3, r.card.addressCount)
    }

    @Test
    fun missingFare() {
        val r = OrderCardParser.parse(listOf(n("ул. Ленина, 5", 300), n("Невский проспект, 10", 420), accept))
        assertNull(r.card.fareRub)
    }

    @Test
    fun bonusWithPlusIsNotFare() {
        val r = OrderCardParser.parse(listOf(n("+50 ₽", 120, 50), n("520 ₽", 150, 90), accept))
        assertEquals(520, r.card.fareRub)
        val onlyBonus = OrderCardParser.parse(listOf(n("доплата +50 ₽", 120, 50), accept))
        assertNull(onlyBonus.card.fareRub)
    }

    @Test
    fun fareWithNonBreakingSpaces() {
        val r = OrderCardParser.parse(listOf(n("1\u00A0250\u00A0₽", 150, 90), accept))
        assertEquals(1250, r.card.fareRub)
    }

    @Test
    fun ambiguousFaresAreNotGuessed() {
        val r = OrderCardParser.parse(listOf(n("520 ₽", 150, 90), n("610 ₽", 250, 90), accept))
        assertNull(r.card.fareRub)
    }

    @Test
    fun withoutAcceptButtonItIsNotAnOffer() {
        val r = OrderCardParser.parse(listOf(n("ул. Ленина, 5", 300), n("520 ₽", 150, 90)))
        assertFalse(r.isOffer)
    }

    @Test
    fun cardChangeProducesDifferentKeys() {
        val a = OrderCardParser.parse(listOf(n("ул. Ленина, 5", 300), n("Невский проспект, 10", 420), accept)).card
        val b = OrderCardParser.parse(listOf(n("ул. Ленина, 5", 300), n("ул. Гагарина, 7", 420), accept)).card
        assertTrue(a.routeKey != b.routeKey)
    }

    @Test
    fun duplicateNodeAtSamePositionIsOneAddress() {
        val r = OrderCardParser.parse(listOf(
            n("ул. Ленина, 5", 300), n("ул. Ленина, 5", 300), n("Невский проспект, 10", 420), accept,
        ))
        assertEquals(2, r.card.addressCount)
    }
}
