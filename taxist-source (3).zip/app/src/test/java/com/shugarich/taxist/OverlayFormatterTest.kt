package com.shugarich.taxist

import com.shugarich.taxist.income.IncomeConfig
import com.shugarich.taxist.model.OrderCard
import com.shugarich.taxist.model.RouteFailure
import com.shugarich.taxist.model.RouteResult
import com.shugarich.taxist.model.RouteState
import com.shugarich.taxist.overlay.OverlayFormatter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OverlayFormatterTest {
    private val nb = '\u00A0'
    private val card = OrderCard("ул. Ленина, 5", "Невский проспект, 10", 520, 2)
    private val full = IncomeConfig(100.0)

    @Test
    fun showsTripRouteAndHourlyIncome() {
        val route = RouteState.Ready(RouteResult(16000, 29 * 60, trafficAware = true))
        val lines = OverlayFormatter.format(card, route, full)
        assertEquals("Заказ: 520 ₽", lines[0])
        assertEquals("Водителю: ≈ 520 ₽ (оценка 100%)", lines[1])
        assertEquals("Доходность: ≈ 1${nb}076 ₽/ч", lines[2])
        assertEquals("Маршрут А → Б: 16 км · 29 мин", lines[3])
    }

    @Test
    fun noTrafficIsDisclosed() {
        val route = RouteState.Ready(RouteResult(16000, 29 * 60, trafficAware = false))
        assertTrue(OverlayFormatter.routeLine(route).contains("без пробок"))
    }

    @Test
    fun loadingNeverShowsNumbers() {
        val lines = OverlayFormatter.format(card, RouteState.Loading, IncomeConfig(63.0))
        assertEquals("Рассчитываю маршрут…", lines[3])
        assertEquals("Доходность: —", lines[2])
        assertFalse(lines.joinToString().contains("км"))
    }

    @Test
    fun failureIsReportedHonestly() {
        val line = OverlayFormatter.routeLine(RouteState.Failed(RouteFailure.NO_NETWORK, null))
        assertEquals("Маршрут не определён: нет интернета", line)
    }

    @Test
    fun missingDestinationAndDisabled() {
        assertTrue(OverlayFormatter.routeLine(RouteState.NoDestination).startsWith("Маршрут не определён"))
        assertTrue(OverlayFormatter.routeLine(RouteState.Disabled).startsWith("Маршрут не определён"))
        assertTrue(OverlayFormatter.routeLine(RouteState.Idle).startsWith("Маршрут не определён"))
    }

    @Test
    fun missingFareAndCommissionData() {
        val noFare = OrderCard("ул. Ленина, 5", "Невский проспект, 10", null, 2)
        val route = RouteState.Ready(RouteResult(16000, 1740, true))
        val lines = OverlayFormatter.format(noFare, route, IncomeConfig(63.0))
        assertEquals("Заказ: цена не считана", lines[0])
        assertEquals("Водителю: —", lines[1])
        assertEquals("Доходность: —", lines[2])
        val badPercent = OverlayFormatter.format(card, route, IncomeConfig(0.0))
        assertEquals("Водителю: —", badPercent[1])
    }

    @Test
    fun distanceAndDurationFormatting() {
        assertEquals("1,2 км", OverlayFormatter.distance(1200))
        assertEquals("5 км", OverlayFormatter.distance(5000))
        assertEquals("16 км", OverlayFormatter.distance(15800))
        assertEquals("1 мин", OverlayFormatter.duration(20))
        assertEquals("29 мин", OverlayFormatter.duration(1740))
        assertEquals("1 ч 5 мин", OverlayFormatter.duration(3900))
    }

    @Test
    fun emptyCardIsLabeled() {
        val lines = OverlayFormatter.format(OrderCard(null, null, null, 0), RouteState.NoAddresses, IncomeConfig(63.0))
        assertEquals("Карточка найдена, данные не распознаны", lines[0])
    }
}
