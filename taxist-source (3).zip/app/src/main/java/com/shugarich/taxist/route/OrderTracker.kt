package com.shugarich.taxist.route

import com.shugarich.taxist.model.OrderCard
import com.shugarich.taxist.model.RouteFailure
import com.shugarich.taxist.model.RouteResult
import com.shugarich.taxist.model.RouteState
import com.shugarich.taxist.model.TrackerSnapshot
import java.util.concurrent.Executor

/**
 * Хранит текущую карточку и состояние маршрута А→Б.
 *
 * Защита от устаревших данных: каждый новый маршрут получает номер поколения; ответ
 * предыдущего заказа игнорируется. Каждый снимок состояния имеет версию, по которой
 * получатель может отбросить запоздавшее уведомление ([isLatest]).
 */
class OrderTracker(
    private val executor: Executor,
    private val compute: (pickup: String, destination: String) -> RouteResult,
    private val routingEnabled: () -> Boolean,
    private val listener: (TrackerSnapshot) -> Unit,
) {
    private val lock = Any()
    private var routeGeneration = 0L
    private var version = 0L
    private var card: OrderCard? = null
    private var route: RouteState = RouteState.Idle

    private val cache = object : LinkedHashMap<String, RouteResult>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, RouteResult>?): Boolean = size > 50
    }

    fun onCard(newCard: OrderCard) {
        var snapshot: TrackerSnapshot? = null
        var job: Runnable? = null
        synchronized(lock) {
            val old = card
            val routeChanged = old == null || old.routeKey != newCard.routeKey
            val sameCard = old != null && old.key == newCard.key
            val routingJustEnabled = sameCard && route === RouteState.Disabled && routingEnabled()
            if (sameCard && !routingJustEnabled) return
            card = newCard
            if (routeChanged || routingJustEnabled) {
                routeGeneration++
                job = startRouteLocked(newCard, routeGeneration)
            }
            version++
            snapshot = TrackerSnapshot(version, card, route)
        }
        snapshot?.let(listener)
        job?.let { executor.execute(it) }
    }

    /** Карточка исчезла: сбросить всё и сделать невалидными поздние ответы. */
    fun clear() {
        var snapshot: TrackerSnapshot? = null
        synchronized(lock) {
            if (card == null) return
            routeGeneration++
            card = null
            route = RouteState.Idle
            version++
            snapshot = TrackerSnapshot(version, null, route)
        }
        snapshot?.let(listener)
    }

    fun isLatest(snapshot: TrackerSnapshot): Boolean = synchronized(lock) { snapshot.version == version }

    private fun startRouteLocked(c: OrderCard, generation: Long): Runnable? {
        val a = c.pickupAddress
        val b = c.destinationAddress
        if (a == null) {
            route = RouteState.NoAddresses
            return null
        }
        if (b == null) {
            route = RouteState.NoDestination
            return null
        }
        if (!routingEnabled()) {
            route = RouteState.Disabled
            return null
        }
        val key = c.routeKey
        val cached = cache[key]
        if (cached != null) {
            route = RouteState.Ready(cached)
            return null
        }
        route = RouteState.Loading
        return Runnable { runRoute(generation, key, a, b) }
    }

    private fun runRoute(generation: Long, key: String, a: String, b: String) {
        val outcome: RouteState = try {
            val result = compute(a, b)
            synchronized(lock) { cache[key] = result }
            RouteState.Ready(result)
        } catch (e: RouteException) {
            RouteState.Failed(e.failure, e.message)
        } catch (e: Exception) {
            RouteState.Failed(RouteFailure.SERVER_ERROR, e.message)
        }
        var snapshot: TrackerSnapshot? = null
        synchronized(lock) {
            if (generation == routeGeneration && card != null) {
                route = outcome
                version++
                snapshot = TrackerSnapshot(version, card, route)
            }
        }
        snapshot?.let(listener)
    }
}
