package com.shugarich.taxist.settings

import android.content.Context
import com.shugarich.taxist.income.IncomeConfig

/** Настройки и статусы проверок. Секретов и API-ключей здесь нет. */
class AppSettings(context: Context) {
    private val p = context.applicationContext.getSharedPreferences("taxi_assistant", Context.MODE_PRIVATE)

    var retentionPercent: Double
        get() = p.getString("retention", null)?.toDoubleOrNull() ?: IncomeConfig.DEFAULT_RETENTION_PERCENT
        set(v) { p.edit().putString("retention", v.toString()).apply() }

    var cityHint: String
        get() = p.getString("city", "") ?: ""
        set(v) { p.edit().putString("city", v).apply() }

    /** По умолчанию выключено: адреса заказов уходят на внешний геокодер только с согласия. */
    var routingEnabled: Boolean
        get() = p.getBoolean("routing", false)
        set(v) { p.edit().putBoolean("routing", v).apply() }

    var routerBaseUrl: String
        get() = p.getString("router", DEFAULT_ROUTER) ?: DEFAULT_ROUTER
        set(v) { p.edit().putString("router", v).apply() }

    var geocoderBaseUrl: String
        get() = p.getString("geocoder", DEFAULT_GEOCODER) ?: DEFAULT_GEOCODER
        set(v) { p.edit().putString("geocoder", v).apply() }

    /** Сохранять текст последней карточки (с адресами) локально для диагностики парсера. */
    var dumpEnabled: Boolean
        get() = p.getBoolean("dump_enabled", false)
        set(v) { p.edit().putBoolean("dump_enabled", v).apply() }

    var lastDump: String
        get() = p.getString("dump", "") ?: ""
        set(v) { p.edit().putString("dump", v).apply() }

    var overlayX: Int
        get() = p.getInt("ox", 16)
        set(v) { p.edit().putInt("ox", v).apply() }

    var overlayY: Int
        get() = p.getInt("oy", 150)
        set(v) { p.edit().putInt("oy", v).apply() }

    var lastRecognizedAt: Long
        get() = p.getLong("recognized_at", 0L)
        set(v) { p.edit().putLong("recognized_at", v).apply() }

    var lastOverlayAt: Long
        get() = p.getLong("overlay_at", 0L)
        set(v) { p.edit().putLong("overlay_at", v).apply() }

    /** 0 — не проверялось, 1 — успешно, 2 — ошибка. */
    var routeTestState: Int
        get() = p.getInt("route_test_state", 0)
        set(v) { p.edit().putInt("route_test_state", v).apply() }

    var routeTestMessage: String
        get() = p.getString("route_test_msg", "") ?: ""
        set(v) { p.edit().putString("route_test_msg", v).apply() }

    fun incomeConfig() = IncomeConfig(retentionPercent)

    companion object {
        const val DEFAULT_ROUTER = "https://router.project-osrm.org"
        const val DEFAULT_GEOCODER = "https://nominatim.openstreetmap.org"
    }
}
