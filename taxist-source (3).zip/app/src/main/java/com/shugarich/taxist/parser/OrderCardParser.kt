package com.shugarich.taxist.parser

import com.shugarich.taxist.model.OrderCard
import com.shugarich.taxist.model.ParseResult
import com.shugarich.taxist.model.RawNode

/**
 * Структурный разбор карточки заказа по отдельным узлам Accessibility.
 *
 * Правила:
 *  - узлы с расстоянием/временем ("3 мин · 1,2 км") — это метрики подачи; они отбрасываются
 *    и никогда не попадают в результат;
 *  - адреса сортируются сверху вниз: первый = А (подача), второй = Б (назначение);
 *  - если адресов больше двух (возможны промежуточные остановки), Б не определяется;
 *  - цена берётся только при однозначном чтении.
 *
 * ВНИМАНИЕ: эвристики подобраны без доступа к реальной вёрстке Яндекс Про и должны быть
 * проверены на реальной карточке (см. MANUAL_TEST_RU.md и диагностику в приложении).
 */
object OrderCardParser {

    private const val L = "А-Яа-яЁёA-Za-z"
    private const val S = "\\s\\u00A0\\u202F"

    private val acceptButton = Regex("^[${S}]*принять(?![${L}])", RegexOption.IGNORE_CASE)

    private val fareStandalone = Regex(
        "^[≈~]?[${S}]*(\\d[\\d${S}]*?)(?:[.,]\\d{1,2})?[${S}]*(?:₽|руб\\.?|р\\.)$",
        RegexOption.IGNORE_CASE,
    )
    private val fareEmbedded = Regex(
        "(\\d[\\d${S}]*?)[${S}]*(?:₽|руб\\.?)",
        RegexOption.IGNORE_CASE,
    )

    /** Единицы расстояния/времени. "м" и "ч" — только после пробела, чтобы не задеть дом "5м". */
    private const val UNIT = "(?:[${S}]*(?:км|мин|km|min)|[${S}]+(?:м|ч))"

    /** Узел целиком состоит из расстояний/времени: "1,2 км", "3 мин · 1,2 км", "29 мин". */
    private val metricsOnly = Regex(
        "^[${S}·•,|/-]*(?:\\d+(?:[.,]\\d+)?${UNIT}\\.?[${S}·•,|/-]*)+$",
        RegexOption.IGNORE_CASE,
    )
    private val trailingMetrics = Regex(
        "[${S}·•,|/-]+(?:\\d+(?:[.,]\\d+)?${UNIT}\\.?[${S}·•,|/-]*)+$",
        RegexOption.IGNORE_CASE,
    )

    private val streetMarker = Regex(
        "(?<![${L}])(?:улица|ул|проспект|просп|пр-кт|пр-т|пр|переулок|пер|шоссе|бульвар|б-р|бул|" +
            "набережная|наб|площадь|пл|проезд|пр-д|аллея|тракт|микрорайон|мкр|квартал|кв-л|" +
            "тупик|линия|просека|дорога|дор)(?![${L}])",
        RegexOption.IGNORE_CASE,
    )
    private val commaThenDigit = Regex("[${L}][^\\d]*,[${S}]*\\d")

    fun parse(nodes: List<RawNode>): ParseResult {
        val isOffer = nodes.any { acceptButton.containsMatchIn(it.text) }
        if (!isOffer) return ParseResult(false, OrderCard(null, null, null, 0))

        val fare = parseFare(nodes)

        val addresses = nodes
            .sortedWith(compareBy<RawNode>({ it.top }, { it.left }))
            .mapNotNull { node -> cleanAddress(node.text)?.let { Triple(it, node.top, node.left) } }
            .distinctBy { Triple(it.first.lowercase(), it.second, it.third) }
            .map { it.first }

        val pickup = addresses.getOrNull(0)
        val destination = if (addresses.size == 2) addresses[1] else null
        return ParseResult(true, OrderCard(pickup, destination, fare, addresses.size))
    }

    internal fun cleanAddress(raw: String): String? {
        val text = raw.trim().replace(Regex("[${S}]+"), " ")
        if (text.length < 5 || text.length > 160) return null
        if (metricsOnly.matches(text)) return null
        if (text.contains('₽')) return null
        val stripped = trailingMetrics.replace(text, "").trim().trimEnd(',', '·', '•', '|', '-', '/').trim()
        if (stripped.length < 5) return null
        if (!stripped.any { it.isLetter() }) return null
        val looksLikeAddress = streetMarker.containsMatchIn(stripped) || commaThenDigit.containsMatchIn(stripped)
        return if (looksLikeAddress) stripped else null
    }

    internal fun parseFare(nodes: List<RawNode>): Int? {
        data class Candidate(val value: Int, val height: Int)

        val standalone = nodes.mapNotNull { n ->
            val t = n.text.trim()
            val m = fareStandalone.find(t) ?: return@mapNotNull null
            toInt(m.groupValues[1])?.let { Candidate(it, n.height) }
        }
        val candidates = if (standalone.isNotEmpty()) standalone else nodes.mapNotNull { n ->
            val t = n.text.trim()
            if (t.length > 24) return@mapNotNull null
            val m = fareEmbedded.find(t) ?: return@mapNotNull null
            val before = t.substring(0, m.range.first).trimEnd().lastOrNull()
            if (before == '+') return@mapNotNull null
            toInt(m.groupValues[1])?.let { Candidate(it, n.height) }
        }
        if (candidates.isEmpty()) return null
        val maxHeight = candidates.maxOf { it.height }
        val top = candidates.filter { it.height == maxHeight }.map { it.value }.distinct()
        return if (top.size == 1) top[0] else null
    }

    private fun toInt(digitsWithSpaces: String): Int? {
        val digits = digitsWithSpaces.filter { it.isDigit() }
        if (digits.isEmpty() || digits.length > 6) return null
        return digits.toIntOrNull()
    }
}
