package com.shugarich.taxist.income

import kotlin.math.roundToInt

/** Доля, остающаяся водителю после комиссий, в процентах. Настраивается пользователем. */
data class IncomeConfig(val retentionPercent: Double = DEFAULT_RETENTION_PERCENT) {
    companion object {
        const val DEFAULT_RETENTION_PERCENT = 63.0
    }
}

object IncomeCalculator {

    /** Оценка дохода водителя. null, если цены нет или процент некорректен. */
    fun driverNet(fareRub: Int?, config: IncomeConfig): Int? {
        if (fareRub == null) return null
        val p = config.retentionPercent
        if (p.isNaN() || p <= 0.0 || p > 100.0) return null
        return (fareRub * p / 100.0).roundToInt()
    }

    /** Доход в час = доход / (время поездки А→Б в часах). null, если времени нет или оно <= 0. */
    fun hourly(netRub: Int?, tripSeconds: Int?): Int? {
        if (netRub == null || tripSeconds == null || tripSeconds <= 0) return null
        return (netRub * 3600.0 / tripSeconds).roundToInt()
    }
}
