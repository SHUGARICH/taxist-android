package com.shugarich.taxist.model

/** Видимый текстовый узел из дерева Accessibility. */
data class RawNode(
    val text: String,
    val viewId: String?,
    val top: Int,
    val left: Int,
    val height: Int,
)

/**
 * Карточка заказа. Адрес подачи (А) и адрес назначения (Б) хранятся раздельно.
 * Расстояние/время подачи сюда намеренно НЕ входят: они не нужны и не должны
 * попасть в строку маршрута.
 */
data class OrderCard(
    val pickupAddress: String?,
    val destinationAddress: String?,
    val fareRub: Int?,
    val addressCount: Int = 0,
) {
    /** Ключ маршрута: меняется только при смене адресов. */
    val routeKey: String
        get() = norm(pickupAddress) + "->" + norm(destinationAddress)

    /** Ключ карточки целиком (адреса + цена). */
    val key: String
        get() = routeKey + "|" + (fareRub?.toString() ?: "")

    val isEmpty: Boolean
        get() = pickupAddress == null && destinationAddress == null && fareRub == null

    private fun norm(s: String?): String =
        s?.lowercase()?.replace(Regex("\\s+"), " ")?.trim() ?: ""
}

data class ParseResult(val isOffer: Boolean, val card: OrderCard)

/** Автомобильный маршрут именно от А до Б. */
data class RouteResult(
    val distanceMeters: Int,
    val durationSeconds: Int,
    /** true, если маршрутизатор учитывает пробки. */
    val trafficAware: Boolean,
)

enum class RouteFailure {
    NO_NETWORK,
    TIMEOUT,
    ADDRESS_NOT_FOUND,
    ADDRESS_AMBIGUOUS,
    NO_ROUTE,
    SERVER_ERROR,
}

sealed class RouteState {
    object Idle : RouteState()
    object NoAddresses : RouteState()
    object NoDestination : RouteState()
    object Disabled : RouteState()
    object Loading : RouteState()
    data class Ready(val result: RouteResult) : RouteState()
    data class Failed(val reason: RouteFailure, val detail: String?) : RouteState()
}

data class TrackerSnapshot(
    val version: Long,
    val card: OrderCard?,
    val route: RouteState,
)
