package com.shugarich.taxist.route

import com.shugarich.taxist.model.RouteFailure
import com.shugarich.taxist.model.RouteResult
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException
import java.net.HttpURLConnection
import java.net.NoRouteToHostException
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.net.UnknownHostException
import java.util.Locale
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

class RouteException(val failure: RouteFailure, message: String? = null) : Exception(message)

data class GeoPoint(val lat: Double, val lon: Double)

interface Geocoder {
    @Throws(RouteException::class)
    fun geocode(query: String): GeoPoint
}

interface RouteProvider {
    /** Автомобильный маршрут от [from] до [to]. Блокирующий вызов, не для главного потока. */
    @Throws(RouteException::class)
    fun route(from: GeoPoint, to: GeoPoint): RouteResult
}

object Geo {
    fun distanceMeters(a: GeoPoint, b: GeoPoint): Double {
        val r = 6371000.0
        val dLat = Math.toRadians(b.lat - a.lat)
        val dLon = Math.toRadians(b.lon - a.lon)
        val h = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(a.lat)) * cos(Math.toRadians(b.lat)) * sin(dLon / 2) * sin(dLon / 2)
        return 2 * r * asin(sqrt(h))
    }
}

/** Адрес А и адрес Б геокодируются раздельно; маршрут строится строго между ними. */
class RoutePipeline(
    private val geocoder: Geocoder,
    private val provider: RouteProvider,
    private val cityHint: () -> String,
) {
    @Throws(RouteException::class)
    fun compute(pickupAddress: String, destinationAddress: String): RouteResult {
        val a = geocoder.geocode(withCity(pickupAddress))
        val b = geocoder.geocode(withCity(destinationAddress))
        return provider.route(a, b)
    }

    internal fun withCity(address: String): String {
        val city = cityHint().trim()
        return if (city.isEmpty() || address.contains(city, ignoreCase = true)) address else "$address, $city"
    }
}

internal object Http {
    @Throws(RouteException::class)
    fun get(url: String): String {
        val conn = try {
            URL(url).openConnection() as HttpURLConnection
        } catch (e: Exception) {
            throw RouteException(RouteFailure.SERVER_ERROR, "Некорректный адрес сервиса")
        }
        try {
            conn.connectTimeout = 5000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", "TaxiAssistant/0.3 (Android; personal use)")
            conn.setRequestProperty("Accept-Language", "ru")
            val code = conn.responseCode
            if (code != 200) {
                val body = try {
                    conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: IOException) {
                    ""
                }
                if (body.contains("NoRoute")) throw RouteException(RouteFailure.NO_ROUTE, "HTTP $code")
                throw RouteException(RouteFailure.SERVER_ERROR, "HTTP $code")
            }
            return conn.inputStream.bufferedReader().use { it.readText() }
        } catch (e: RouteException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw RouteException(RouteFailure.TIMEOUT, e.message)
        } catch (e: UnknownHostException) {
            throw RouteException(RouteFailure.NO_NETWORK, e.message)
        } catch (e: ConnectException) {
            throw RouteException(RouteFailure.NO_NETWORK, e.message)
        } catch (e: NoRouteToHostException) {
            throw RouteException(RouteFailure.NO_NETWORK, e.message)
        } catch (e: IOException) {
            throw RouteException(RouteFailure.SERVER_ERROR, e.message)
        } finally {
            conn.disconnect()
        }
    }

    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}

object NominatimParser {
    @Throws(RouteException::class)
    fun parse(json: String): GeoPoint {
        val arr = try {
            JSONArray(json)
        } catch (e: JSONException) {
            throw RouteException(RouteFailure.SERVER_ERROR, "Ответ геокодера не распознан")
        }
        if (arr.length() == 0) throw RouteException(RouteFailure.ADDRESS_NOT_FOUND)
        val points = (0 until arr.length()).mapNotNull { i ->
            val o: JSONObject = arr.optJSONObject(i) ?: return@mapNotNull null
            val lat = o.optString("lat").toDoubleOrNull()
            val lon = o.optString("lon").toDoubleOrNull()
            if (lat != null && lon != null) GeoPoint(lat, lon) else null
        }
        if (points.isEmpty()) throw RouteException(RouteFailure.SERVER_ERROR, "В ответе геокодера нет координат")
        val first = points[0]
        if (points.any { Geo.distanceMeters(first, it) > 3000.0 }) {
            throw RouteException(RouteFailure.ADDRESS_AMBIGUOUS)
        }
        return first
    }
}

/**
 * Геокодер OpenStreetMap Nominatim. Публичный сервер: не более 1 запроса в секунду,
 * обязателен User-Agent. Для интенсивного использования нужен свой сервер или платный сервис.
 */
class NominatimGeocoder(private val baseUrl: () -> String) : Geocoder {
    private val cache = object : LinkedHashMap<String, GeoPoint>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, GeoPoint>?): Boolean = size > 100
    }
    private val rateLock = Any()
    private var lastRequestAt = 0L

    override fun geocode(query: String): GeoPoint {
        val key = query.lowercase().trim()
        synchronized(cache) { cache[key] }?.let { return it }
        val json = synchronized(rateLock) {
            val wait = lastRequestAt + 1100L - System.currentTimeMillis()
            if (wait > 0) {
                try {
                    Thread.sleep(wait)
                } catch (e: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
            try {
                Http.get("${baseUrl().trimEnd('/')}/search?format=jsonv2&limit=3&countrycodes=ru&q=${Http.enc(query)}")
            } finally {
                lastRequestAt = System.currentTimeMillis()
            }
        }
        val point = NominatimParser.parse(json)
        synchronized(cache) { cache[key] = point }
        return point
    }
}

object OsrmParser {
    @Throws(RouteException::class)
    fun parse(json: String): RouteResult {
        val o = try {
            JSONObject(json)
        } catch (e: JSONException) {
            throw RouteException(RouteFailure.SERVER_ERROR, "Ответ маршрутизатора не распознан")
        }
        when (o.optString("code")) {
            "Ok" -> Unit
            "NoRoute" -> throw RouteException(RouteFailure.NO_ROUTE)
            else -> throw RouteException(RouteFailure.SERVER_ERROR, o.optString("code"))
        }
        val routes = o.optJSONArray("routes")
        if (routes == null || routes.length() == 0) throw RouteException(RouteFailure.NO_ROUTE)
        val r = routes.optJSONObject(0) ?: throw RouteException(RouteFailure.NO_ROUTE)
        val distance = r.optDouble("distance", -1.0)
        val duration = r.optDouble("duration", -1.0)
        if (distance < 0.0 || duration <= 0.0) {
            throw RouteException(RouteFailure.SERVER_ERROR, "В ответе нет расстояния или времени")
        }
        // OSRM считает по свободным дорогам: пробки не учитываются.
        return RouteResult(distance.roundToInt(), duration.roundToInt(), trafficAware = false)
    }
}

/** Маршрутизатор OSRM (совместимый API). По умолчанию — публичный демо-сервер, без учёта пробок. */
class OsrmRouteProvider(private val baseUrl: () -> String) : RouteProvider {
    override fun route(from: GeoPoint, to: GeoPoint): RouteResult {
        fun f(v: Double) = String.format(Locale.US, "%.6f", v)
        val url = "${baseUrl().trimEnd('/')}/route/v1/driving/" +
            "${f(from.lon)},${f(from.lat)};${f(to.lon)},${f(to.lat)}?overview=false&alternatives=false"
        return OsrmParser.parse(Http.get(url))
    }
}
