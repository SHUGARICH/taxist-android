package com.shugarich.taxist

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.shugarich.taxist.model.RawNode
import com.shugarich.taxist.model.TrackerSnapshot
import com.shugarich.taxist.overlay.OverlayFormatter
import com.shugarich.taxist.overlay.OverlayView
import com.shugarich.taxist.parser.OrderCardParser
import com.shugarich.taxist.route.NominatimGeocoder
import com.shugarich.taxist.route.OrderTracker
import com.shugarich.taxist.route.OsrmRouteProvider
import com.shugarich.taxist.route.RoutePipeline
import com.shugarich.taxist.settings.AppSettings
import com.shugarich.taxist.settings.ServiceStatus
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Читает видимый текст Яндекс Про, передаёт его парсеру и показывает оверлей.
 * Ничего не нажимает и не принимает/отклоняет заказы.
 */
class OrderReaderService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private lateinit var settings: AppSettings
    private lateinit var tracker: OrderTracker
    private lateinit var overlay: OverlayView
    private var executor: ExecutorService? = null

    private var scanScheduled = false
    private var hideScheduled = false
    private var dismissed = false
    private var overlayStampedForKey: String? = null

    private val scanRunnable = Runnable {
        scanScheduled = false
        scanScreen()
    }
    private val hideRunnable = Runnable {
        hideScheduled = false
        tracker.clear()
        overlay.hide()
        dismissed = false
        overlayStampedForKey = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        settings = AppSettings(this)
        val pool = Executors.newFixedThreadPool(2)
        executor = pool
        val pipeline = RoutePipeline(
            NominatimGeocoder { settings.geocoderBaseUrl },
            OsrmRouteProvider { settings.routerBaseUrl },
            { settings.cityHint },
        )
        tracker = OrderTracker(
            executor = pool,
            compute = { a, b -> pipeline.compute(a, b) },
            routingEnabled = { settings.routingEnabled },
            listener = { snap -> main.post { render(snap) } },
        )
        overlay = OverlayView(this, settings) { dismissed = true; overlay.hide() }
        ServiceStatus.connected = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !::tracker.isInitialized) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == YANDEX_PRO) {
            if (!scanScheduled) {
                scanScheduled = true
                main.postDelayed(scanRunnable, 150)
            }
        } else if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            pkg != packageName && pkg != "com.android.systemui"
        ) {
            // Пользователь ушёл в другое приложение — карточки больше нет.
            hideRunnable.run()
        }
    }

    private fun scanScreen() {
        val root = rootInActiveWindow
        if (root == null || root.packageName?.toString() != YANDEX_PRO) {
            scheduleHide()
            recycle(root)
            return
        }
        try {
            val nodes = ArrayList<RawNode>()
            collect(root, nodes, 0)
            val parsed = OrderCardParser.parse(nodes)
            if (!parsed.isOffer) {
                scheduleHide()
                return
            }
            main.removeCallbacks(hideRunnable)
            hideScheduled = false
            if (!parsed.card.isEmpty) settings.lastRecognizedAt = System.currentTimeMillis()
            if (settings.dumpEnabled) saveDump(nodes)
            tracker.onCard(parsed.card)
        } finally {
            recycle(root)
        }
    }

    private fun scheduleHide() {
        if (!hideScheduled) {
            hideScheduled = true
            main.postDelayed(hideRunnable, 700)
        }
    }

    private fun render(snap: TrackerSnapshot) {
        if (!tracker.isLatest(snap)) return
        val card = snap.card
        if (card == null) {
            overlay.hide()
            return
        }
        if (dismissed) return
        overlay.show(OverlayFormatter.format(snap, settings.incomeConfig()))
        if (overlayStampedForKey != card.routeKey) {
            overlayStampedForKey = card.routeKey
            settings.lastOverlayAt = System.currentTimeMillis()
        }
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<RawNode>, depth: Int) {
        if (out.size >= 400 || depth > 40) return
        if (node.isVisibleToUser) {
            val t = node.text?.toString()?.takeIf { it.isNotBlank() }
                ?: node.contentDescription?.toString()?.takeIf { it.isNotBlank() }
            if (t != null) {
                val r = Rect()
                node.getBoundsInScreen(r)
                out.add(RawNode(t.trim(), node.viewIdResourceName, r.top, r.left, r.height()))
            }
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                collect(child, out, depth + 1)
            } finally {
                recycle(child)
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun recycle(node: AccessibilityNodeInfo?) {
        try {
            node?.recycle()
        } catch (e: Exception) {
            // не критично
        }
    }

    private fun saveDump(nodes: List<RawNode>) {
        val text = nodes.sortedWith(compareBy<RawNode>({ it.top }, { it.left }))
            .joinToString("\n") { "top=${it.top} left=${it.left} h=${it.height} id=${it.viewId ?: "-"} | ${it.text}" }
        if (text != settings.lastDump) settings.lastDump = text.take(20000)
    }

    override fun onInterrupt() {
        if (::tracker.isInitialized) hideRunnable.run()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        ServiceStatus.connected = false
        main.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) overlay.hide()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        ServiceStatus.connected = false
        main.removeCallbacksAndMessages(null)
        if (::overlay.isInitialized) overlay.hide()
        executor?.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val YANDEX_PRO = "ru.yandex.taximeter"
    }
}
