package com.shugarich.taxist.settings

/** true только пока служба реально подключена системой (onServiceConnected выполнен). */
object ServiceStatus {
    @Volatile
    var connected: Boolean = false
}
