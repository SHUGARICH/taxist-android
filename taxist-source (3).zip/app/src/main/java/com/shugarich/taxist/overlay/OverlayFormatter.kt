package com.shugarich.taxist.overlay

import com.shugarich.taxist.income.IncomeCalculator
import com.shugarich.taxist.income.IncomeConfig
import com.shugarich.taxist.model.OrderCard
import com.shugarich.taxist.model.RouteFailure
import com.shugarich.taxist.model.RouteState
import com.shugarich.taxist.model.TrackerSnapshot
import java.util.Locale
import kotlin.math.roundToInt

/** Чистое форматирование строк оверлея. Маршрут берётся ТОЛЬКО из [RouteState.Ready]. */
object OverlayFormatter {
    const val ROUTE_LABEL = "Маршрут А → Б"
    private const val NBSP = '\u00A0'

    fun format(snapshot: TrackerSnapshot, config: IncomeConfig): List<String> =
        format(snapshot.card, snapshot.route, config)

    fun format(card: OrderCard?, route: RouteState, config: IncomeConfig): List<String> {
        val fare = card?.fareRub
        val net = IncomeCalculator.driverNet(fare, config)
        val tripSeconds = (route as? RouteState.Ready)?.result?.durationSeconds
        val hourly = IncomeCalculator.hourly(net, tripSeconds)

        val lines = mutableListOf<String>()
        if (card != null && card.isEmpty) lines += "Карточка найдена, данные не распознаны"
        lines += "Заказ: " + (fare?.let { money(it) + " ₽" } ?: "цена не считана")
        lines += "Водителю: " + (net?.let { "≈ " + money(it) + " ₽ (оценка ${percent(config.retentionPercent)}%)" } ?: "—")
        lines += "Доходность: " + (hourly?.let { "≈ " + money(it) + " ₽/ч" } ?: "—")
        lines += routeLine(route)
        return lines
    }

    fun routeLine(route: RouteState): String = when (route) {
        is RouteState.Ready -> {
            val r = route.result
            ROUTE_LABEL + ": " + distance(r.distanceMeters) + " · " + duration(r.durationSeconds) +
                (if (r.trafficAware) "" else " (без пробок)")
        }
        RouteState.Loading -> "Рассчитываю маршрут…"
        RouteState.Idle -> "Маршрут не определён"
        RouteState.NoAddresses -> "Маршрут не определён: адреса не распознаны"
        RouteState.NoDestination -> "Маршрут не определён: адрес назначения не распознан"
        RouteState.Disabled -> "Маршрут не определён: расчёт выключен в настройках"
        is RouteState.Failed -> "Маршрут не определён: " + failureText(route.reason)
    }

    fun failureText(f: RouteFailure): String = when (f) {
        RouteFailure.NO_NETWORK -> "нет интернета"
        RouteFailure.TIMEOUT -> "сервер не ответил вовремя"
        RouteFailure.ADDRESS_NOT_FOUND -> "адрес не найден"
        RouteFailure.ADDRESS_AMBIGUOUS -> "адрес неоднозначен (укажите город в настройках)"
        RouteFailure.NO_ROUTE -> "маршрут не найден"
        RouteFailure.SERVER_ERROR -> "ошибка сервиса маршрутов"
    }

    fun distance(meters: Int): String {
        val km = meters / 1000.0
        if (km >= 10.0) return "${km.roundToInt()} км"
        val s = String.format(Locale.US, "%.1f", km)
        return (if (s.endsWith(".0")) s.dropLast(2) else s.replace('.', ',')) + " км"
    }

    fun duration(seconds: Int): String {
        val minutes = maxOf(1, (seconds / 60.0).roundToInt())
        return if (minutes < 60) "$minutes мин" else "${minutes / 60} ч ${minutes % 60} мин"
    }

    fun money(value: Int): String = String.format(Locale.US, "%,d", value).replace(',', NBSP)

    private fun percent(p: Double): String =
        if (p % 1.0 == 0.0) p.toInt().toString() else p.toString().replace('.', ',')
}
