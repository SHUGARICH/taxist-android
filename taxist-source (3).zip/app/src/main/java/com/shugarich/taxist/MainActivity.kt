package com.shugarich.taxist

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import com.shugarich.taxist.overlay.OverlayFormatter
import com.shugarich.taxist.route.Geocoder
import com.shugarich.taxist.route.NominatimGeocoder
import com.shugarich.taxist.route.OsrmRouteProvider
import com.shugarich.taxist.route.RouteException
import com.shugarich.taxist.settings.AppSettings
import com.shugarich.taxist.settings.ServiceStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var settings: AppSettings
    private lateinit var statusService: TextView
    private lateinit var statusOverlay: TextView
    private lateinit var statusRecognition: TextView
    private lateinit var statusRouting: TextView
    private lateinit var retention: EditText
    private lateinit var city: EditText
    private lateinit var routerUrl: EditText
    private lateinit var geocoderUrl: EditText
    private lateinit var routingSwitch: Switch
    private lateinit var dumpSwitch: Switch

    private val green = Color.rgb(76, 175, 80)
    private val yellow = Color.rgb(255, 193, 7)
    private val red = Color.rgb(244, 67, 54)
    private val gray = Color.rgb(158, 158, 158)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(24))
        }
        root.addView(text("TAXI ASSISTANT", 26f, yellow).apply { gravity = Gravity.CENTER })
        root.addView(text(
            "Показывает по карточке Яндекс Про: цену, оценку дохода, ₽/ч и маршрут А → Б. " +
                "Не принимает и не отклоняет заказы.", 14f, Color.WHITE,
        ).apply { setPadding(0, dp(8), 0, dp(12)) })

        root.addView(section("Состояние"))
        statusService = text("", 14f, gray); root.addView(statusService)
        statusOverlay = text("", 14f, gray); root.addView(statusOverlay)
        statusRecognition = text("", 14f, gray); root.addView(statusRecognition)
        statusRouting = text("", 14f, gray); root.addView(statusRouting)

        root.addView(button("1. Открыть настройки специальных возможностей") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(section("Расчёт дохода"))
        root.addView(text("Доля заказа, которая остаётся водителю после комиссий, %. " +
            "Это оценка, а не гарантированная выплата: комиссия зависит от тарифа и парка.", 12f, gray))
        retention = input("63", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        root.addView(retention)

        root.addView(section("Маршрут А → Б"))
        routingSwitch = Switch(this).apply {
            text = "Считать маршрут по адресам заказа"
            setTextColor(Color.WHITE)
        }
        root.addView(routingSwitch)
        root.addView(text(
            "Если включено, адреса А и Б из карточки отправляются на публичный геокодер " +
                "(Nominatim/OpenStreetMap), а координаты — на маршрутизатор (OSRM). Это адреса пассажира. " +
                "Включайте только осознанно. Публичный OSRM не учитывает пробки, время будет без них.",
            12f, gray,
        ))
        root.addView(text("Город по умолчанию (добавляется к адресам без города)", 12f, gray))
        city = input("например: Москва", InputType.TYPE_CLASS_TEXT)
        root.addView(city)
        root.addView(text("Адрес маршрутизатора (OSRM-совместимый, https)", 12f, gray))
        routerUrl = input(AppSettings.DEFAULT_ROUTER, InputType.TYPE_TEXT_VARIATION_URI)
        root.addView(routerUrl)
        root.addView(text("Адрес геокодера (Nominatim-совместимый, https)", 12f, gray))
        geocoderUrl = input(AppSettings.DEFAULT_GEOCODER, InputType.TYPE_TEXT_VARIATION_URI)
        root.addView(geocoderUrl)

        root.addView(button("Сохранить настройки") { if (save()) Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show() })
        root.addView(button("Проверить связь с геокодером и маршрутизатором") { runRouteTest() })

        root.addView(section("Диагностика"))
        dumpSwitch = Switch(this).apply {
            text = "Сохранять текст последней карточки (для настройки парсера)"
            setTextColor(Color.WHITE)
        }
        root.addView(dumpSwitch)
        root.addView(text("Текст хранится только на телефоне и содержит адреса из карточки. " +
            "Он уходит куда-либо, только если вы сами нажмёте «Поделиться».", 12f, gray))
        root.addView(button("Поделиться текстом последней карточки") { shareDump() })

        root.addView(section("Первоначальная настройка"))
        root.addView(text(
            "1. Нажмите кнопку выше и включите «Taxi Assistant» в специальных возможностях " +
                "(Android может спросить подтверждение или потребовать сначала открыть «О приложении» → меню ⋮ → " +
                "«Разрешить ограниченные настройки»).\n" +
                "2. Отдельное разрешение «поверх других приложений» не требуется: окно показывается через службу " +
                "специальных возможностей.\n" +
                "3. По желанию включите расчёт маршрута, укажите город и сохраните.\n" +
                "4. Откройте Яндекс Про и дождитесь карточки заказа. Статусы выше станут зелёными только после " +
                "реальной проверки.", 13f, Color.WHITE,
        ))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.rgb(18, 19, 22))
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        retention.setText(formatPercent(settings.retentionPercent))
        city.setText(settings.cityHint)
        routerUrl.setText(settings.routerBaseUrl)
        geocoderUrl.setText(settings.geocoderBaseUrl)
        routingSwitch.isChecked = settings.routingEnabled
        dumpSwitch.isChecked = settings.dumpEnabled
        refreshStatus()
    }

    override fun onPause() {
        super.onPause()
        save()
    }

    private fun refreshStatus() {
        val enabled = isServiceEnabledInSystem()
        when {
            !enabled -> setStatus(statusService, red, "Служба чтения: выключена в специальных возможностях")
            !ServiceStatus.connected -> setStatus(statusService, yellow,
                "Служба чтения: включена, но ещё не подключилась (подождите или выключите и включите её снова)")
            else -> setStatus(statusService, green, "Служба чтения: подключена")
        }

        val ov = settings.lastOverlayAt
        if (ov == 0L) setStatus(statusOverlay, gray,
            "Окно оверлея: разрешение не нужно; показ ещё не проверен на реальной карточке")
        else setStatus(statusOverlay, green, "Окно оверлея: показывалось ${fmt(ov)}")

        val rec = settings.lastRecognizedAt
        if (rec == 0L) setStatus(statusRecognition, gray, "Распознавание карточки: не проверено")
        else setStatus(statusRecognition, green,
            "Распознавание карточки: данные считаны ${fmt(rec)} (корректность А/Б проверьте глазами)")

        if (!settings.routingEnabled) setStatus(statusRouting, gray, "Маршрут А → Б: выключен, адреса никуда не отправляются")
        else when (settings.routeTestState) {
            1 -> setStatus(statusRouting, green, "Маршрут А → Б: " + settings.routeTestMessage)
            2 -> setStatus(statusRouting, red, "Маршрут А → Б: " + settings.routeTestMessage)
            else -> setStatus(statusRouting, yellow, "Маршрут А → Б: включён, связь не проверена")
        }
    }

    private fun isServiceEnabledInSystem(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val full = ComponentName(this, OrderReaderService::class.java).flattenToString()
        val short = ComponentName(this, OrderReaderService::class.java).flattenToShortString()
        return enabled.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    private fun save(): Boolean {
        val pct = retention.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (pct == null || pct <= 0.0 || pct > 100.0) {
            Toast.makeText(this, "Процент дохода должен быть от 1 до 100", Toast.LENGTH_LONG).show()
            return false
        }
        val router = routerUrl.text.toString().trim().trimEnd('/')
        val geo = geocoderUrl.text.toString().trim().trimEnd('/')
        if (!router.startsWith("https://") || !geo.startsWith("https://")) {
            Toast.makeText(this, "Адреса сервисов должны начинаться с https://", Toast.LENGTH_LONG).show()
            return false
        }
        settings.retentionPercent = pct
        settings.cityHint = city.text.toString().trim()
        settings.routerBaseUrl = router
        settings.geocoderBaseUrl = geo
        val wasRouting = settings.routingEnabled
        settings.routingEnabled = routingSwitch.isChecked
        if (wasRouting != routingSwitch.isChecked) settings.routeTestState = 0
        settings.dumpEnabled = dumpSwitch.isChecked
        return true
    }

    private fun runRouteTest() {
        if (!save()) return
        setStatus(statusRouting, yellow, "Маршрут А → Б: проверяю связь…")
        Thread {
            var state = 1
            var message: String
            try {
                // Тестовые адреса, не связанные с заказами; адреса пассажиров не отправляются.
                val geocoder: Geocoder = NominatimGeocoder { settings.geocoderBaseUrl }
                val a = geocoder.geocode("Москва, Тверская улица, 1")
                val b = geocoder.geocode("Москва, улица Арбат, 10")
                val r = OsrmRouteProvider { settings.routerBaseUrl }.route(a, b)
                message = "связь есть (тест: " + OverlayFormatter.distance(r.distanceMeters) + " · " +
                    OverlayFormatter.duration(r.durationSeconds) + "), " + fmt(System.currentTimeMillis())
            } catch (e: RouteException) {
                state = 2
                message = OverlayFormatter.failureText(e.failure) + " (" + fmt(System.currentTimeMillis()) + ")"
            } catch (e: Exception) {
                state = 2
                message = "ошибка: " + (e.message ?: e.javaClass.simpleName)
            }
            runOnUiThread {
                settings.routeTestState = state
                settings.routeTestMessage = message
                refreshStatus()
            }
        }.start()
    }

    private fun shareDump() {
        val dump = settings.lastDump
        if (dump.isBlank()) {
            Toast.makeText(this, "Нет данных: включите сохранение и откройте карточку заказа", Toast.LENGTH_LONG).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, dump)
        }
        startActivity(Intent.createChooser(send, "Поделиться диагностикой"))
    }

    private fun fmt(ms: Long): String = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault()).format(Date(ms))

    private fun formatPercent(p: Double): String = if (p % 1.0 == 0.0) p.toInt().toString() else p.toString()

    private fun setStatus(view: TextView, color: Int, message: String) {
        view.text = "●  $message"
        view.setTextColor(color)
    }

    private fun text(s: String, size: Float, color: Int) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        setPadding(0, dp(4), 0, dp(4))
    }

    private fun section(title: String) = text(title.uppercase(Locale.getDefault()), 13f, yellow).apply {
        setPadding(0, dp(18), 0, dp(4))
    }

    private fun input(hint: String, type: Int) = EditText(this).apply {
        this.hint = hint
        inputType = type
        setTextColor(Color.WHITE)
        setHintTextColor(gray)
        setSingleLine(true)
    }

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setAllCaps(false)
        setOnClickListener { onClick() }
    }
}
