package com.shugarich.taxist.overlay

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.shugarich.taxist.settings.AppSettings

/**
 * Одно компактное перетаскиваемое окно. Используется TYPE_ACCESSIBILITY_OVERLAY, поэтому
 * отдельное разрешение «поверх других приложений» не требуется. Окно создаётся один раз
 * и только обновляется — наложения нескольких экземпляров быть не может.
 */
class OverlayView(
    private val context: Context,
    private val settings: AppSettings,
    private val onClose: () -> Unit,
) {
    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = context.resources.displayMetrics.density
    private var root: LinearLayout? = null
    private var content: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null

    private var startX = 0
    private var startY = 0
    private var touchX = 0f
    private var touchY = 0f

    val isShown: Boolean get() = root != null

    private fun dp(v: Int): Int = (v * density).toInt()

    fun show(lines: List<String>) {
        try {
            if (root == null) create()
            val c = content ?: return
            c.removeAllViews()
            lines.forEachIndexed { i, line ->
                c.addView(TextView(context).apply {
                    text = line
                    maxWidth = dp(270)
                    textSize = if (i == lines.lastIndex) 13f else 15f
                    setTextColor(if (line.startsWith("Доходность")) Color.rgb(255, 193, 7) else Color.WHITE)
                })
            }
        } catch (e: Exception) {
            hide()
        }
    }

    fun hide() {
        val r = root
        if (r != null) {
            try {
                wm.removeView(r)
            } catch (e: Exception) {
                // окно уже снято системой
            }
        }
        root = null
        content = null
        params = null
    }

    private fun create() {
        val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val close = TextView(context).apply {
            text = "✕"
            textSize = 14f
            gravity = Gravity.END
            setTextColor(Color.rgb(255, 193, 7))
            setPadding(dp(14), 0, 0, dp(2))
            setOnClickListener { onClose() }
        }
        val box = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(6), dp(10), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 18, 20, 25))
                cornerRadius = dp(10).toFloat()
            }
            addView(close)
            addView(body)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = settings.overlayX
            y = settings.overlayY
        }
        box.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startY = lp.y
                    touchX = ev.rawX
                    touchY = ev.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (ev.rawX - touchX).toInt()
                    lp.y = startY + (ev.rawY - touchY).toInt()
                    try {
                        wm.updateViewLayout(box, lp)
                    } catch (e: Exception) {
                        // окно могло быть снято
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    settings.overlayX = lp.x
                    settings.overlayY = lp.y
                    true
                }
                else -> false
            }
        }
        wm.addView(box, lp)
        root = box
        content = body
        params = lp
    }
}
